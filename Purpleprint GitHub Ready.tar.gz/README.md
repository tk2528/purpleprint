# PurplePrint Dashboard

An interactive customer journey map dashboard for surfacing research insights across the food delivery, Q-Commerce, and pick-up verticals.

## 🌐 Live Demo

Once deployed, your dashboard will be available at:
`https://[your-username].github.io/purpleprint-dashboard`

## ✨ Features

- **Multi-select screen filtering** - Combine multiple product screens to see cross-screen insights
- **Role-based lenses** - View insights organized by Business, Product, or Design decision-making
- **User type filtering** - Filter by New users, Existing users, or All
- **Journey mapping** - Visualize the complete customer journey with ease-of-use scores
- **Interactive UI** - Glassmorphism design with smooth animations and responsive interactions

## 🚀 Quick Start (GitHub Pages)

### 1. Create a new repository on GitHub
- Go to [github.com/new](https://github.com/new)
- Name it `purpleprint-dashboard`
- Keep it **Public** (required for free GitHub Pages)
- Don't initialize with README (we already have one)
- Click **Create repository**

### 2. Push this code to GitHub

Run these commands in your terminal:

```bash
cd purpleprint-dashboard
git add .
git commit -m "Initial commit: PurplePrint dashboard"
git remote add origin https://github.com/[YOUR-USERNAME]/purpleprint-dashboard.git
git push -u origin main
```

Replace `[YOUR-USERNAME]` with your actual GitHub username.

### 3. Enable GitHub Pages

- Go to your repository on GitHub
- Click **Settings** → **Pages** (in the left sidebar)
- Under "Source", select **Deploy from a branch**
- Under "Branch", select **main** and **/ (root)**
- Click **Save**

**Your dashboard will be live in 1-2 minutes!** 🎉

GitHub will show you the URL where it's published (usually `https://[your-username].github.io/purpleprint-dashboard`)

## 📊 Data

Currently includes insights from:
- **Food Delivery** vertical
- 8 product screens across the customer journey
- 5 journey stages (Awareness → Feedback)
- Business, Product, and Design lenses

## 🛠️ Technology

- Pure HTML/CSS/JavaScript
- React 18 (loaded via CDN)
- No build process required
- Fully self-contained single file

## 📝 Notes

This is a static dashboard. All data is embedded in the HTML file. To update insights:
1. Edit `index.html`
2. Modify the `INSIGHTS` array
3. Commit and push changes
4. GitHub Pages will auto-deploy

---

Built with Claude for stakeholder demonstrations and research insight accessibility.
